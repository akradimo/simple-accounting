<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasTable('projects')) {
            Schema::create('projects', function (Blueprint $table) {
                $table->id();
                $table->string('name')->comment('نام پروژه');
                $table->string('code')->nullable()->unique()->comment('کد پروژه');
                $table->text('description')->nullable()->comment('توضیحات');
                $table->date('start_date')->nullable()->comment('تاریخ شروع');
                $table->date('end_date')->nullable()->comment('تاریخ پایان');
                $table->string('status')->default('active')->comment('وضعیت');
                $table->text('notes')->nullable()->comment('یادداشت‌ها');
                $table->foreignId('created_by')->nullable()->constrained('users')
                    ->comment('ایجاد کننده');
                $table->foreignId('updated_by')->nullable()->constrained('users')
                    ->comment('ویرایش کننده');
                $table->timestamps();
                $table->softDeletes();
            });
        } else {
            Schema::table('projects', function (Blueprint $table) {
                // اضافه کردن ستون‌های جدید در صورت نبود
                if (!Schema::hasColumn('projects', 'code')) {
                    $table->string('code')->nullable()->unique()->after('name')
                        ->comment('کد پروژه');
                }
                if (!Schema::hasColumn('projects', 'start_date')) {
                    $table->date('start_date')->nullable()->after('description')
                        ->comment('تاریخ شروع');
                }
                if (!Schema::hasColumn('projects', 'end_date')) {
                    $table->date('end_date')->nullable()->after('start_date')
                        ->comment('تاریخ پایان');
                }
                if (!Schema::hasColumn('projects', 'status')) {
                    $table->string('status')->default('active')->after('end_date')
                        ->comment('وضعیت');
                }
                if (!Schema::hasColumn('projects', 'notes')) {
                    $table->text('notes')->nullable()->after('status')
                        ->comment('یادداشت‌ها');
                }
                if (!Schema::hasColumn('projects', 'created_by')) {
                    $table->foreignId('created_by')->nullable()->constrained('users')
                        ->comment('ایجاد کننده');
                }
                if (!Schema::hasColumn('projects', 'updated_by')) {
                    $table->foreignId('updated_by')->nullable()->constrained('users')
                        ->comment('ویرایش کننده');
                }
                if (!Schema::hasColumn('projects', 'deleted_at')) {
                    $table->softDeletes();
                }
            });
        }

        // اضافه کردن ایندکس‌ها
        Schema::table('projects', function (Blueprint $table) {
            $table->index('status');
            $table->index('created_by');
            $table->index('updated_by');
        });
    }

    public function down()
    {
        if (Schema::hasTable('projects')) {
            Schema::table('projects', function (Blueprint $table) {
                $table->dropColumn([
                    'code',
                    'start_date',
                    'end_date',
                    'status',
                    'notes',
                    'created_by',
                    'updated_by',
                    'deleted_at'
                ]);
            });
        }
    }
};