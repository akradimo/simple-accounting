<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // جدول اصلی دریافت
        Schema::create('receipts', function (Blueprint $table) {
            $table->id();
            $table->string('number', 8)->unique()->comment('شماره دریافت');
            $table->date('date')->comment('تاریخ دریافت');
            $table->foreignId('project_id')->nullable()->constrained('projects')
                ->onDelete('restrict')->comment('پروژه مربوطه');
            $table->string('description', 200)->nullable()->comment('شرح دریافت');
            $table->string('currency', 3)->default('IRR')->comment('واحد پول');
            $table->foreignId('person_id')->constrained('people')
                ->onDelete('restrict')->comment('شخص');
            $table->decimal('amount', 20, 0)->default(0)->comment('مبلغ');
            $table->boolean('is_active')->default(true)->comment('وضعیت');
            $table->string('created_by')->nullable()->comment('ایجاد کننده');
            $table->string('updated_by')->nullable()->comment('ویرایش کننده');
            $table->timestamps();
            $table->softDeletes();

            // ایندکس‌ها
            $table->index('date');
            $table->index('project_id');
            $table->index('person_id');
            $table->index('is_active');
        });

        // جدول آیتم‌های دریافت
        Schema::create('receipt_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('receipt_id')->constrained()->onDelete('cascade')
                ->comment('دریافت مربوطه');
            $table->foreignId('contact_id')->constrained('people')
                ->comment('شخص دریافت کننده');
            $table->decimal('amount', 20, 0)->default(0)->comment('مبلغ');
            $table->text('description')->nullable()->comment('شرح');
            $table->timestamps();

            // ایندکس‌ها
            $table->index('receipt_id');
            $table->index('contact_id');
        });

        // جدول پرداخت‌های دریافت
        Schema::create('receipt_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('receipt_id')->constrained()->onDelete('cascade')
                ->comment('دریافت مربوطه');
            $table->enum('type', ['cash', 'petty-cash', 'bank', 'check', 'contact', 'account'])
                ->comment('نوع پرداخت');
            $table->decimal('amount', 20, 0)->default(0)->comment('مبلغ');
            $table->string('reference')->nullable()->comment('شماره مرجع');
            $table->json('details')->nullable()->comment('جزئیات');
            $table->timestamps();

            // ایندکس‌ها
            $table->index('receipt_id');
            $table->index('type');
        });
    }

    public function down()
    {
        Schema::dropIfExists('receipt_payments');
        Schema::dropIfExists('receipt_items');
        Schema::dropIfExists('receipts');
    }
};