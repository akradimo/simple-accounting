<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('person_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');             // نام دسته‌بندی
            $table->string('color', 7);         // رنگ (#RRGGBB)
            $table->string('icon')->nullable(); // نام آیکون
            $table->text('description')->nullable(); // توضیحات
            $table->integer('order')->default(0);   // ترتیب نمایش
            $table->boolean('is_active')->default(true); // وضعیت
            $table->timestamps();
            $table->softDeletes();
        });

        // اضافه کردن ستون category_id به جدول people
        Schema::table('people', function (Blueprint $table) {
            $table->foreignId('category_id')->nullable()->constrained('person_categories')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('people', function (Blueprint $table) {
            $table->dropForeign(['category_id']);
            $table->dropColumn('category_id');
        });
        Schema::dropIfExists('person_categories');
    }
};