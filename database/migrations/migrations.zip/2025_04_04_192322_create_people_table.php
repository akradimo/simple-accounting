<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('people', function (Blueprint $table) {
            $table->id();
            $table->string('code', 6)->unique();              // کد شش رقمی یکتا
            $table->string('title')->nullable();              // عنوان (آقا، خانم، دکتر و...)
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('display_name')->nullable();       // نام نمایشی یا مستعار
            $table->string('national_code', 10)->nullable()->unique();
            $table->string('economic_code', 12)->nullable();
            $table->string('registration_number', 20)->nullable();
            $table->enum('type', ['individual', 'company'])->default('individual');
            $table->string('company_name')->nullable();
            
            // اطلاعات تماس
            $table->string('mobile', 11)->nullable();
            $table->string('phone', 11)->nullable();
            $table->string('email')->nullable();
            $table->string('website')->nullable();
            $table->text('address')->nullable();
            $table->string('postal_code', 10)->nullable();
            $table->string('country')->default('ایران');
            $table->string('state')->nullable();
            $table->string('city')->nullable();
            
            // دسته‌بندی و وضعیت
            $table->string('category')->default('اشخاص');     // اشخاص، سهامداران، کارمندان و...
            $table->boolean('is_customer')->default(false);    // مشتری
            $table->boolean('is_supplier')->default(false);    // تامین کننده
            $table->boolean('is_employee')->default(false);    // کارمند
            $table->boolean('is_shareholder')->default(false); // سهامدار
            
            // اطلاعات مالی
            $table->decimal('credit_limit', 20, 2)->default(0);  // سقف اعتبار
            $table->decimal('opening_balance', 20, 2)->default(0); // مانده اول دوره
            
            $table->string('image')->nullable();     // تصویر
            $table->text('description')->nullable(); // توضیحات
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('people');
    }
};